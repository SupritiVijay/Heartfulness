import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'file:///Users/apple/AndroidStudioProjects/E-commerce-Complete-Flutter-UI/lib/components/my_bottom_nav_bar.dart';
import 'package:shop_app/screens/home/components/body.dart';
import 'package:shop_app/size_config.dart';
import 'package:shop_app/enums.dart';

class HomeScreen extends StatelessWidget {
  static String routeName = "/home";
  @override
  Widget build(BuildContext context) {
    SizeConfig().init(context);
    return Scaffold(
      appBar: buildAppBar(),
      body: Body(),
      bottomNavigationBar: MyBottomNavBar(),
    );
  }

  AppBar buildAppBar() {
    return AppBar(
      leading: IconButton(
        icon: SvgPicture.asset("assets/icons/menu.svg"),
        onPressed: () {},
      ),
      // On Android by default its false
      centerTitle: true,
      title: RichText(
        text: TextSpan(
          style: TextStyle(fontSize: 25.0),
          children: [
            TextSpan(
              text: "Heart",
              style: TextStyle(color: Colors.lightGreen,
                  fontWeight: FontWeight.bold),
            ),
            TextSpan(
              text: "Fullness",
              style: TextStyle(color: Colors.blueGrey),
            ),
          ],
        ),
      ),
      actions: <Widget>[
        IconButton(
           icon: SvgPicture.asset("assets/icons/Chat bubble Icon.svg"),
          onPressed: () {},
        ),
        SizedBox(
          // It means 5 because by out defaultSize = 10
          width: SizeConfig.defaultSize * 0.5,
        )
      ],
    );
  }
}
