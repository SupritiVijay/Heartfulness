import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:shop_app/models/RecipeBundel.dart';

import '../../../size_config.dart';

class RecipeBundelCard extends StatelessWidget {
  final RecipeBundle recipeBundle;
  final Function press;

  const RecipeBundelCard({Key key, this.recipeBundle, this.press})
      : super(key: key);
  @override
  Widget build(BuildContext context) {
    double defaultSize = SizeConfig.defaultSize;
    return GestureDetector(
      onTap: press,
      child: Container(
          decoration: BoxDecoration(
            color: recipeBundle.color,
            borderRadius: BorderRadius.circular(defaultSize * 1.8), //18
            image: DecorationImage(
              image: AssetImage(recipeBundle.imageSrc),
              fit: BoxFit.fitWidth,
              alignment: Alignment.topCenter,
            ),
          ),
          child: Row(
            children: <Widget>[
              Expanded(
                child: Padding(
                  padding: EdgeInsets.all(defaultSize * 2), //20
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Spacer(),
                      Text(
                        recipeBundle.title,
                        style: TextStyle(
                            fontSize: defaultSize * 2.2, //22
                            color: Colors.white),

                      ),
                      SizedBox(height: defaultSize * 0.5), // 5
                      Text(
                        recipeBundle.description,
                        style: TextStyle(color: Colors.white54),
                      ),
                      Spacer(),
                      Row(
                        children: [
                          CircleAvatar(
                            radius: 15,
                            child: ClipRRect(
                              borderRadius:
                              BorderRadius.circular(100),
                              child: Image.asset(
                                "assets/images/pic.png",
                                fit: BoxFit.fill,
                              ),
                            ),
                          ),
                          SizedBox(
                            width: 10,
                          ),
                          FittedBox(
                              child: Text("Robert Patinson"
                              )
                          )
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ],
          )
      ),
    );
  }
  }


