import 'package:flutter/material.dart';

class RecipeBundle {
  final String title, description, imageSrc;
  final Color color;

  RecipeBundle(
      {
      this.title,
      this.description,
      this.imageSrc,
      this.color});
}

// Demo list
List<RecipeBundle> recipeBundles = [
  RecipeBundle(
    title: "Porbandar Bird Sanctuary",
    description: "Fun for a Good Cause",
    imageSrc: "assets/images/bird.jpg",
    color: Color(0xFFD82D40),
  ),
  RecipeBundle(
    title: "Mother Teresa Organization",
    description: "Donating rice for poor people",
    imageSrc: "assets/images/rice.jpg.png",
    color: Color(0xFF90AF17),
  ),
  RecipeBundle(
    title: "Tree Plantation",
    description: "Planting trees in the neighbourhood",
    imageSrc: "assets/images/planting trees.jpg",
    color: Color(0xFF2DBBD8),
  ),
];
